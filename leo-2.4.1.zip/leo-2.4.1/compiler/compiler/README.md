# leo-compiler

[![Crates.io](https://img.shields.io/crates/v/leo-compiler.svg?color=neon)](https://crates.io/crates/leo-compiler)
[![Authors](https://img.shields.io/badge/authors-Aleo-orange.svg)](../AUTHORS)
[![License](https://img.shields.io/badge/License-GPLv3-blue.svg)](./LICENSE.md)
