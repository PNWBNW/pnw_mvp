---
name: 📚 Documentation
about: Report an issue related to documentation
title: "[Docs]"
labels: 'documentation'
---

## 📚 Documentation

<!--
    Did you find a mistake in the Leo documentation?
    Is there documentation about Leo that's missing?
-->

(Write your answer here.)
