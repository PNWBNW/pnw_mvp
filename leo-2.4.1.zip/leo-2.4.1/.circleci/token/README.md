<!-- # 🪙 Token -->

[//]: # (<img alt="workshop/token" width="1412" src="../.resources/token.png">)

A transparent & shielded custom token in Leo.

## Run Guide

To run this program, run:
```bash
./run.sh
```