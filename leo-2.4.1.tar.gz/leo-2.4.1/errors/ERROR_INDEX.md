# Leo Error Index

## Parser Errors: Error Code Range 370_000 - 370_999

## AST Errors: Error Code Range 372_000 - 372_999

## ASG Errors: Error Code Range 373_000 - 373_999

## Import Errors: Error Code Range 374_000 - 374_999

## Package Errors: Error Code Range 375_000 - 375_999

## Compiler Errors: Error Code Range 376_000 - 376_999

## CLI Errors: Error Code Range 377_000 - 377_999
